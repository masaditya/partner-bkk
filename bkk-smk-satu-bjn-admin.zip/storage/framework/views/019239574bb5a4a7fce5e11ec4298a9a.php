<script defer src="<?php echo e(asset('tail-admin/bundle.js')); ?>"></script>

<?php /**PATH C:\laragon\www\bkk-smk-satu-bjn-admin\resources\views/includes/js.blade.php ENDPATH**/ ?>