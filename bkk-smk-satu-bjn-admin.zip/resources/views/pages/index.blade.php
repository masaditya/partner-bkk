@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<main>
    
</main>

@endsection