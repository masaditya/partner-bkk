<script defer src="{{ asset('tail-admin/bundle.js') }}"></script>

